package messagerie;

import java.util.Date;


public class MessageVocal extends AbstractMessage{


	//constructeur
	public MessageVocal(String message, AbstractCommMessage comMessage){
		super(message, comMessage);
		
	}
	
	
	public String getMessage(){
		return message;
	}
}
