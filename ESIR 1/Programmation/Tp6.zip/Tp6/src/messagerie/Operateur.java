package messagerie;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.ListIterator;

public class Operateur{
/**
 * Un Op�rateur g�re des abonn�s et des communications
 */
	//attributs 
	private List<AbonneOperateur> liste;
	private Date datefin;
	private String nomOperateur;
	private List<Appel> listeAp;
	private AbstractCommMessage comMessage;
	
	//Constructeur
	public Operateur(String nomOperateur){
		List<AbonneOperateur> liste = new ArrayList <AbonneOperateur>();
		this.liste = liste;
		this.nomOperateur = nomOperateur;
		List<Appel> listeAp = new ArrayList <Appel>();
	}	
	
	
  /**
   * Une personne souscrit un abonnement et re�oit un t�l�phone
   */
  public Telephone souscrire(String nomPersonne, String nomForfait) {
    NumeroTelephone numero = new NumeroTelephone();
    Telephone tel = null;
    Forfait nomF = new Forfait(nomForfait);
    AbonneOperateur abonne = new AbonneOperateur(tel,nomF,nomPersonne,numero);
    Telephone telephone = new Telephone(abonne);
    liste.add(abonne);
    return telephone;
    
  }


	/*	
   * �tablir une communication
   * @param emetteur
   * @param numeroDestinataire
   * @param msgVocal : message en cas d'indisponibilit�
   * @param dateAppel
   * @return vrai si la communication a �t� �tablie
   */
  public boolean etablirCommunication(AbonneOperateur emetteur, String numeroDestinataire, String msgVocal, Date dateAppel)
  {
	  
	  int i = 0;
	 
	  while ( (i<liste.size()) && (!numeroDestinataire.equals(liste.get(i).getNum().getNum()))) //Tant qu'on a pas atteint le max de la liste et tant qu'on a pas trouv� l'abonn� en question.
	  {
		  //Si le num�ro pass� en param�tre est trouv� dans la liste des abonn�s
		  if(numeroDestinataire.equals(liste.get(i).getNum().getNum())) //Comparaison entre le num�ro � qui on souhaite envoyer le sms et le num�ro de l'abonn� dans la liste
		  {
			  AbonneOperateur recepteur = liste.get(i);
			  while (recepteur.estLibre()){
				  if (emetteur.appeler(numeroDestinataire,msgVocal,dateAppel) && recepteur.accepterAppel(emetteur.getNum().getNum())){
					  Appel a = new Appel (emetteur.getNum(), recepteur.getNum(), dateAppel);
					  return true;
				  }

		  }
		  i = i+1;
	  }
	}
	  return false;
  }

  /**
   * poster un SMS
   * @param emetteur
   * @param numeroDestinataire
   * @param sms : le texte du SMS
   * @pamra dateEnvoi
   */
  public void posterSMS(AbonneOperateur emetteur, String numeroDestinataire, String sms, Date dateEnvoi)
  {
	  int i = 0;
	  AbonneOperateur recepteur1 = getAbonne(numeroDestinataire);
	  AbstractCommMessage comMessage = new CommSMS(dateEnvoi, emetteur.getNum(), recepteur1.getNum());
	  MessageSMS message = new MessageSMS(sms, comMessage);
	  while ( (i<liste.size()) && (!numeroDestinataire.equals(liste.get(i).getNum().getNum()))) //Tant qu'on a pas atteint le max de la liste et tant qu'on a pas trouv� l'abonn� en question.
	  {
		  //Si le num�ro pass� en param�tre est trouv� dans la liste des abonn�s
		  if(numeroDestinataire.equals(liste.get(i).getNum().getNum())) //Comparaison entre le num�ro � qui on souhaite envoyer le sms et le num�ro de l'abonn� dans la liste
		  {
			  AbonneOperateur recepteur2 = liste.get(i);
			  BoiteSMS br = recepteur2.getBoiteSMS();
			  BoiteSMS be = emetteur.getBoiteSMS();
			  br.ajouterSMS(message);
			  be.ajouterSMS(message);//On envoi le SMS sur la boite SMS du destinataire.
			  System.out.println("Message Envoy� !");
			  message = null;
			  break;
		  }
		  i = i+1;
	  }
	 

  }

  /**
   * un abonn� met fin � une communication
   * @param abonne : celui qui cl�t
   * @param date de fin de communication
   */
  public void cloreAppel(AbonneOperateur abonne, Date fin){
	  Appel appel = getAppel(abonne); //retrouver l'appel correspondant � l'abonn�
	  appel.terminerAppel(fin); //terminer l'appel
	  this.datefin = fin;
	  
	  
  }
  
  
  public void facturation(AbonneOperateur abonne)
  {
	  System.out.println("Facture de : "+abonne.getNom());
	  System.out.println("Montant : "+getMontantCom(abonne));
  }
  
  public double getMontantCom(AbonneOperateur abonne)
  {
	  double montanttotal = 0;
	  double minutesappels = abonne.getDureeAppels();
	  double montant1 = 0; //montant "1h"
	  double montant2 = 0; //montant � l'acte
	  if (minutesappels > 60) 
	  { 
		  montant1 = abonne.getDureeAppels() - 60; //minutes suppl�mentaires
		  montant1 = montant1 * 0.15; //facturation
	  }
	  else
	  {
		  montant2 = minutesappels * 0.15; 
	  }
	  double montant3 = abonne.getNbSMS(); //montant messages
	  double consultations = abonne.NbConsultations() * 0.07; //prix relatif aux consultations de la boite vocale
	  if (montant3 > 0) //plus d'un message
	  {
		  montant3 = montant3 * 0.07; //facturation
	  }
	  
	  String f = abonne.getForfait().getNom();
	  if (f.equals("illimit�"))
	  {
		  montanttotal = 40;
	  }
	  else if (f.equals("1h"))
	  {
		  montanttotal = 20 + montant1 + montant3 + consultations; //prix de base + frais suppl�mentaires
	  }
	  else if (f.equals("a l'acte"))
	  {
		  montanttotal = montant2 + montant3 + consultations;
	  }
	return montanttotal;
  }
  
  public Appel getAppel(AbonneOperateur abonne)
  {
	  ListIterator <Appel> it= listeAp.listIterator();
	  while(it.hasNext())
	  {
		  Appel cur = it.next();
		  if(cur.getEmetteur().equals(abonne) || cur.getRecepteur().equals(abonne)) //si l'abonn� est l'appelant ou l'appel�
		  {
			  return cur; //renvoi de l'appel
		  }
	  }
	  return null;
  }
  
  public AbonneOperateur getAbonne(String telephone) //donne un AbonneOperateur en fonction d'un num�ro
  {
	  ListIterator <AbonneOperateur> it= liste.listIterator();
	  while(it.hasNext())
	  {
		  AbonneOperateur cur = it.next();
		  if(cur.getNum().equals(telephone)) //si l'abonn� est l'appelant ou l'appel�
		  {
			  return cur; //renvoi de l'appel
		  }
	  }
	  return null;
	  
  }
  
  public List<AbonneOperateur> getListe(){
	  return liste;
  }
  
  public String getNomOperateur()
  {
	  return nomOperateur;
  }
} // Operateur