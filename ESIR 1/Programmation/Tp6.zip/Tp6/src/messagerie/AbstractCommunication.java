package messagerie;

import java.util.Date;

public abstract class AbstractCommunication {
	
	protected Date debut;
	protected NumeroTelephone emetteur;
	protected NumeroTelephone	recepteur;
	
	public AbstractCommunication(Date debut, NumeroTelephone emetteur, NumeroTelephone recepteur)
	{
		this.debut = debut;
		this.emetteur = emetteur;
		this.recepteur = recepteur;
	}
	
	public Date getDebCom() {
		return this.debut;
	}
	
	public NumeroTelephone getNumeroEmetteur()
	{
		return this.emetteur;
	}
	
	public NumeroTelephone getNumeroRecepteur()
	{
		return this.recepteur;
	}
}