package messagerie;
import java.util.Date;

/**
 * Informations d'Abonn� g�r�es par l'op�rateur
 */
public class AbonneOperateur implements GestionCommunication
{
	//attributs
	private Telephone tel;
	private Forfait nomForfait;
	private String nomPersonne;
	private BoiteSMS b1;
	private Date datefin;
	private Date datedebut;
	private NumeroTelephone num;
	private String msgVocal;
	private Operateur operateur;
	private BoiteVocale b2;
	private int dureeAppels;
	private int Nbconsultations; //nombre de consultations de la boite vocale
	
	
	
	//constructeur
	public AbonneOperateur(Telephone tel,Forfait nomForfait,String nomPersonne,NumeroTelephone numero){
		this.tel=tel;
		this.num = numero;
		this.nomForfait = nomForfait;
		this.nomPersonne=nomPersonne;
		BoiteSMS b1 = new BoiteSMS();
		BoiteVocale b2 = new BoiteVocale();
		this.b2 = b2;
		this.b1 = b1;
		this.dureeAppels =0;
	}
	

	
  //------------------------------------------------------------------------
  // m�thodes de l'interface GestionCommunication
  //------------------------------------------------------------------------
 

	public boolean appeler(String numero, String msgVocalSiOccupe, Date dateDebut){
		for (int i=0; i<operateur.getListe().size(); i++)
		{
			AbonneOperateur recepteur = operateur.getListe().get(i);
			//Si le num�ro pass� en param�tre est trouv� dans la liste des abonn�s
			if(numero.equals(recepteur.num)) //Comparaison entre le num�ro � qui on souhaite envoyer le sms et le num�ro de l'abonn� dans la liste
			{
				if(!accepterAppel(this.num.numero)){
					AbstractCommMessage comMessage = new CommMessageVocal(dateDebut,recepteur.getNum(),this.num);
					MessageVocal message = new MessageVocal(msgVocalSiOccupe,comMessage);
					recepteur.getBoiteVocale().ajouterMesVoc(message);
					return false;
				}
				return true;
			}
			
		}
		return false;


	}

	
  public void envoyerSMS(String numero, String sms, Date dateSMS) {
	  this.operateur.posterSMS(this, numero, sms, dateSMS);
  }
 
  
  public void recevoirSMS(MessageSMS message){
	  if(estHorsLigne()){this.b1.ajouterSMS(message);}
	  else {tel.recevoirSMS(message);}
  }
  
  
  public boolean accepterAppel(String numeroAppelant)
  {
	  if (this.estLibre())
	  {
		  return this.tel.accepterAppel(numeroAppelant);
	  }
	  return false;
  }

  
  public void cloreAppel(Date fin){
	 this.operateur.cloreAppel(this, fin);
  }

  //------------------------------------------------------------------------
  // autres m�thodes
  //------------------------------------------------------------------------
 
  public NumeroTelephone getNum(){
	  return num;
  }
  public Telephone getTel(){
	  return tel;
	  
  }
  
  public BoiteSMS getBoiteSMS(){
	  return b1;
  }
  
  public BoiteVocale getBoiteVocale(){
	  return b2;
  }
  // transf�rer sur le t�l�phone les SMS du serveur
  public void synchroniser()
  {
	  int a = this.b1.getNbSMS();
	  int i = 0;
	  while (i != a)
	  {
		  MessageSMS message = this.b1.getNouveauSMS(); //on recupere les message situ�s sur le serveur
		  this.tel.getBoite().ajouterSMS(message); //envoi au t�l�phone
		  i++;
	  }
  }

  boolean estHorsLigne(){
    if(tel.esteteint()){return true;}
	return false;
  }

  boolean estLibre()
  {
	  if(tel.estallume()){return true;}
		return false;
  }
  
  public int getDureeAppels()
  {
	  return this.dureeAppels;
  }
  
  public int getNbSMS()
  {
	  return b1.getNbSMS();
  }
  
  public String getNom()
  {
	  return nomPersonne;
  }
  
  public Forfait getForfait(){
	  return this.nomForfait;
  }
  
  public void ConsulterMessagerie()
  {
	  this.b2.lireNouveauxMessagesVocaux();
	  this.Nbconsultations += 1;
  }
  
  public int NbConsultations()
  {
	  return this.Nbconsultations;
  }


} // AbonneOperateur