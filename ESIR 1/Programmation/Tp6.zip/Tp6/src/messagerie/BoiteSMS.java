package messagerie;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

public class BoiteSMS {
	//attributs
	private List<MessageSMS>boiteSMS;
	private int nbSMS;
	
	
	//constructeurs
	public BoiteSMS(){
		List<MessageSMS>boiteSMS = new ArrayList<MessageSMS>();
		this.boiteSMS =boiteSMS;
		this.nbSMS = 0;
	}
	
	//m�thodes
	public void ajouterSMS(MessageSMS message){
		this.boiteSMS.add(message);
		this.nbSMS = nbSMS+1;
		
	}
	
	public int getNbSMS(){
		return this.nbSMS;
	
	}
	
	public MessageSMS getMessage(MessageSMS sms){
		return sms;
	}
	
	public MessageSMS getNouveauSMS()
	{
		ListIterator <MessageSMS> it = boiteSMS.listIterator();
		while(it.hasNext())
		{
			MessageSMS cur = it.next();
			it.remove();
			return cur;
		}
		return null;
	}
	
	public void supprimer() //supprimer tous les sms
	{
		boiteSMS.clear();
	}

	
}
