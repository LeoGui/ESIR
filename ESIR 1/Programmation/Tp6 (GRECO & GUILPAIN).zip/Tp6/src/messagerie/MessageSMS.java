// GRECO Vincent & GUILPAIN L�o

package messagerie;

public class MessageSMS extends AbstractMessage {
	//constructeur
	public MessageSMS(String message, AbstractCommMessage comMessage){
		super(message, comMessage);
	}

}
